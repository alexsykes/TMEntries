<script src="https://cdn.tiny.cloud/1/musi1wv2kebgt1z2g4j9gymziz98ctscmixwe5hc7s2x5ve9/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
<script>
    tinymce.init({
        selector: 'textarea.withEditor', // Replace this CSS selector to match the placeholder element for TinyMCE
        plugins: 'code table lists',
        toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist',


    });
</script>









<?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/components/head/tinymce-config.blade.php ENDPATH**/ ?>