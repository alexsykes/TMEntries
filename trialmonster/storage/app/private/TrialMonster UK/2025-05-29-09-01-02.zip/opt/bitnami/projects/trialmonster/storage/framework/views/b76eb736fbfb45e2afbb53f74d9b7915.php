<?php if (isset($component)) { $__componentOriginal27ace535957143cef069f9d3d7f387f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ace535957143cef069f9d3d7f387f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> Entries for <?php echo e($user->name); ?> <?php $__env->endSlot(); ?>

    <?php
        /* Paid status
            0 - New entry within limit, not paid
            1 - Confirmed entry
            2 - Withdrawn, having paid, waiting for refund
            3 - Refunded entries
            4 - Reserve - invoiced, awaiting payment
            5 - Reserve - not paid
            6 - Removed
            7 - Manual entry - unpaid
            8 - Manual entry - paid
            9 - Manual entry - FoC
        */
        $statusArray = array('Unconfirmed Entry - to pay', 'Confirmed Entry', 'Refund Pending', 'Refunded Entry');

    $status = array('Awaiting payment', 'Confirmed Entry','Awaiting Refund', 'Refunded', 'Reserve - awaiting payment', 'Reserve', 'Removed by admin', 'Manual Entry - to pay', 'Manual Entry - paid', 'Manual Entry - FoC' );
    ?>

<div class="space-y-4">
    <div class="px-4 py-0 pb-2 mt-6 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300">
        <table class="text-sm">
        <?php $__currentLoopData = $entriesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entryArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="flex-auto odd:bg-white  even:bg-gray-50  border-b " >
                    td class="pt-4 font-semibold text-blue-800 " colspan="4"><?php echo e($statusArray[$entryArray[0]->status]); ?></td></tr>
                <?php $__currentLoopData = $entryArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td class=""><?php echo e($entry->name); ?></td>
                  <td class="pl-4"><?php echo e($entry->course); ?></td>
                  <td class="pl-4"><?php echo e($entry->class); ?></td>
                  <td class="pl-4"><?php echo e($entry->make); ?> <?php echo e($entry->size); ?></td>
              </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $attributes = $__attributesOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__attributesOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $component = $__componentOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__componentOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/entries/user_entry_list.blade.php ENDPATH**/ ?>