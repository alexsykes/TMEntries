<?php if (isset($component)) { $__componentOriginal27ace535957143cef069f9d3d7f387f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ace535957143cef069f9d3d7f387f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> 
        TrialMonster UK
     <?php $__env->endSlot(); ?>
    <div class=" bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">

        <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600">Coming up…</div>
            <table class="w-full">
                <?php $__currentLoopData = $trials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $date = date_format(date_create($trial->date), "M jS, Y");
                    ?>
                   <tr class="flex-auto odd:bg-white  even:bg-gray-50  border-b ">
                        <td class="pl-2 text-sm hidden md:table-cell"><a href="/trial/details/<?php echo e($trial->id); ?>"><?php echo e($date); ?></a></td>
                        <td class="text-sm hidden md:table-cell"><a href="/trial/details/<?php echo e($trial->id); ?>"><?php echo e($trial->club); ?></a></td>
                        <td class="text-sm pl-2 table-cell"><a href="/trial/details/<?php echo e($trial->id); ?>"><?php echo e($trial->name); ?></a></td>
                        <td title="Entry list" class="table-cell" ><a href="/trial/<?php echo e($trial->id); ?>/entrylist"><span><i class="text-xl  fa-solid fa-list-ul"></i></span></a></td>
                        <td title="Register" class="table-cell "><a href="/trial/details/<?php echo e($trial->id); ?>"><span><i class="text-xl  fa-solid fa-circle-info"></i></span></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $attributes = $__attributesOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__attributesOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $component = $__componentOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__componentOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/trials/trial_list.blade.php ENDPATH**/ ?>