<?php if (isset($component)) { $__componentOriginal485bac47280a588df973e561cc36e261 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal485bac47280a588df973e561cc36e261 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.club','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('club'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> 
        <?php echo e($trial->name); ?>

     <?php $__env->endSlot(); ?>

    <div class="mx-auto max-w-7xl px-4  sm:px-6 lg:px-8">
        <?php

            $isEntryLocked = $trial->isEntryLocked;
    $isTrialLocked = $trial->isLocked;
    if($isEntryLocked || $isTrialLocked) {
        $lock = true;
    } else {
        $lock = false;
    }

    $duplicateArray = array();
    foreach($duplicates as $duplicate)
        {
            array_push($duplicateArray, $duplicate->ridingNumber);
        }
        $statusOptions = array(    'Unconfirmed', 'Confirmed', 'Withdrawn - paid awaiting refund', 'Refunded', 'Accepted - awaiting payment', 'Reserve', 'Removed', 'Manual entry - to pay', 'Manual entry - paid', 'Manual entry - FoC');
        $manualStatusOptions = array(  'Manual entry - to pay', 'Manual entry - paid', 'Manual entry - FoC');
        $classes = explode(',',$trial->classlist);
        $courses = explode(',',$trial->courselist);
        $authority = $trial->authority;
        $types = array("2 stroke", "4 stroke", "e-bike");
        $entryOptions = array( 'Manual entry - to pay', 'Manual entry - paid', 'Manual entry - FoC');


                $allCourses = array();
$courses = $trial->courselist;
$customCourses = $trial->customCourses;

$allClasses = array();
$classes = $trial->classlist;
$customClasses = $trial->customClasses;

if($courses !='') {
array_push($allCourses, $courses);
}

if($customCourses !='') {
array_push($allCourses, $customCourses);
}

if($classes !='') {
array_push($allClasses, $classes);
}

if($customClasses !='') {
array_push($allClasses, $customClasses);
}

$classlist = str_replace(',',',',implode(',', $allClasses));
$courselist   = str_replace(',',',',implode(',', $allCourses));
$courseOptions = explode(',', $courselist);
$classOptions = explode(',', $classlist);
        ?>
        <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
            <div class="flex justify-between font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-violet-600">
                <div>Entry list</div>
            </div>
                <table class="w-full text-sm">
                    <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(in_array($entry->ridingNumber, $duplicateArray)): ?>
                            <tr class="flex-auto text-red-500 odd:bg-white  even:bg-gray-50  border-b ">

                        <?php else: ?>

                            <tr class="flex-auto odd:bg-white even:bg-gray-50  border-b ">
                        <?php endif; ?>
                            <td class="text-right pr-2 w-12 py-1"><?php echo e($entry->ridingNumber); ?></td>
                            <td><?php echo e($entry->name); ?></td>
                            <td><?php echo e($entry->class); ?></td>
                            <td><?php echo e($entry->course); ?></td>
                            <td><?php echo e($statusOptions[$entry->status]); ?></td>
                                <?php if(!$lock): ?>
                            <td><a href="/admin/entry/edit/<?php echo e($entry->id); ?>"><span><i class="fa-solid fa-gear"></i></span></a>
                            </td>
                            <td><a href="/admin/entry/cancel/<?php echo e($entry->id); ?>"><span><i
                                                class="fa-solid fa-ban"></i></span></a></td>
                                    <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            
        </div>
        <div class="mt-4 ml-0" id="buttons1">
            <?php if(!$lock): ?>
            <a href="/admin/entries/editRidingNumbers/<?php echo e($trial->id); ?>"
               class="rounded-md ml-2 bg-violet-600 px-3 py-2 text-sm font-light  border border-violet-800 text-white drop-shadow-lg hover:bg-violet-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-600">Edit Riding Numbers</a>

            <?php endif; ?>
            <a href="/admin/entries/printSignOnSheets/<?php echo e($trial->id); ?>"
               class="rounded-md ml-2 bg-violet-600 px-3 py-2 text-sm font-light  border border-violet-800 text-white drop-shadow-lg hover:bg-violet-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-600">Signing-on Sheets</a>
        </div>
<?php if(!$lock): ?>
        <form action="/admin/entries/storeMultiple" method="POST">
        <div class="mt-4   bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
            <div class=" font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-violet-600">Add Manual Entries</div>

                <input type="hidden" id="trialID" name="trialID" value="<?php echo e($trial->id); ?>">
                <?php echo csrf_field(); ?>

                <table class="w-full text-sm pt-0" style="padding: 0px;">


                    <?php for($i=0; $i<10; $i++): ?>
                        <tr class="flex-auto">
                            <td class="table-cell pl-2 py-1"><input class="m-1  w-12 bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1"  type="text" id="ridingNumber[]" name="ridingNumber[]"/></td>
                            <td class="table-cell py-1"><input class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1"  type="text" id="name[]" name="name[]" placeholder="Rider"/></td>

                            <td class="table-cell py-1"><input class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1"  type="text" id="make[]" name="make[]" placeholder="Make"/></td>
                            <td class="table-cell py-1"><input class="m-1  w-12 bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1"  type="text" id="size[]" name="size[]" placeholder="Size"/></td>
                            <td class="table-cell">
                                <select class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1" id="type[]" name="type[]">
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td class="table-cell pl-2">
                                <select class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1" id="course[]" name="course[]">
                                    <?php $__currentLoopData = $courseOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($course); ?>"><?php echo e($course); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td class="table-cell pl-2">
                                <select class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1" id="class[]" name="class[]">
                                    <?php $__currentLoopData = $classOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class); ?>"><?php echo e($class); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td class="table-cell">
                                <select class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1" id="status[]" name="status[]">
                                    <option value="8">Cash</option>
                                    <option value="7">Pay on day</option>
                                    <option value="9">FoC</option>
                                </select>
                            </td>

                            <td class="table-cell"><label for="isYouth">Under 18</label>
                                <input class="m-1  bg-white  space-x-4 border-spacing-1 border-violet-700 rounded-md drop-shadow-lg pl-2 pr-2 pt-1 pb-1 border outline-1 -outline-offset-1"  type="checkbox" id="isYouth[]" name="isYouth[]" value="1">
                            </td>

                        </tr>

                    <?php endfor; ?>
                </table>
        </div>
                <div class="mt-4" id="buttons">

                    <button type="submit"
                            class="rounded-md ml-2 bg-violet-600 px-3 py-1 text-sm font-light  border border-violet-800 text-white drop-shadow-lg hover:bg-violet-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-600">
                        Add Entries
                    </button>
                </div>

            </form>
<?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal485bac47280a588df973e561cc36e261)): ?>
<?php $attributes = $__attributesOriginal485bac47280a588df973e561cc36e261; ?>
<?php unset($__attributesOriginal485bac47280a588df973e561cc36e261); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal485bac47280a588df973e561cc36e261)): ?>
<?php $component = $__componentOriginal485bac47280a588df973e561cc36e261; ?>
<?php unset($__componentOriginal485bac47280a588df973e561cc36e261); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/trials/admin_entry_list.blade.php ENDPATH**/ ?>