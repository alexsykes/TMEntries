<label {{ $attributes->merge(['class' => 'block text-m font-bold leading-6 text-blue-700']) }}>{{ $slot }}</label>
