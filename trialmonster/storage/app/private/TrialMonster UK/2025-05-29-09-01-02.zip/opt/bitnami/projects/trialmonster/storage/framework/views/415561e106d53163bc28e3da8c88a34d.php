<label for="<?php echo e($for); ?>" <?php echo e($attributes); ?>>
    <?php echo e($slot->isNotEmpty() ? $slot : $fallback); ?>

</label>
<?php /**PATH /opt/bitnami/projects/trialmonster/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/forms/label.blade.php ENDPATH**/ ?>