<?php $__env->startSection('title', __('TrialMonster Closed for Updates')); ?>
<?php $__env->startSection('code', '503'); ?>
<?php $__env->startSection('message', __('TrialMonster is currently undergoing some maintenance and updates. Please call again soon.')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/errors/503.blade.php ENDPATH**/ ?>