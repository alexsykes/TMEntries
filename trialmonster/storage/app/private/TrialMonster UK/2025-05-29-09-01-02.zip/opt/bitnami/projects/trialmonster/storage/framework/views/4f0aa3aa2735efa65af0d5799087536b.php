<?php if (isset($component)) { $__componentOriginal485bac47280a588df973e561cc36e261 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal485bac47280a588df973e561cc36e261 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.club','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('club'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> 
        Information
     <?php $__env->endSlot(); ?>

    <?php
        $statusArray = array('Awaiting payment', 'Confirmed Entry','Awaiting Refund', 'Refunded', 'Reserve - awaiting payment', 'Reserve', 'Removed by admin', 'Manual Entry - to pay', 'Manual Entry - paid', 'Manual Entry - FoC' );

//        dd($entries);
    ?>

    <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="  w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  font-semibold text-white bg-violet-600"><?php echo e($venue->name); ?></div>
            <div class="sm: flex justify-between text-sm w-full pl-4 pr-4 pt-2">
                <div class="sm: table-cell w-1/2"><b>Landowner:</b> <?php echo e($venue->landowner); ?></div>
                <div class="sm: table-cell text-right w-1/2"><b>Phone:</b> <?php echo e($venue->phone); ?></div>
            </div>

        <div class="flex justify-between text-sm w-full pl-4 pr-4 pt-2">
            <div class="sm: table-cell w-1/2"><b>Address:</b> <?php echo e($venue->address); ?></div>
            <div class="sm: table-cell text-right w-1/2"><b>Postcode:</b> <?php echo e($venue->postcode); ?></div>
        </div>

        <div class="flex justify-between text-sm w-full pl-4 pr-4 pt-2">
            <div class="sm: table-cell w-full"><?php echo "<b>Directions:</b> ".$venue->directions; ?></div>
        </div>

        <div class="flex justify-between text-sm w-full pl-4 pr-4 pt-2">
            <div class="sm: table-cell w-full"><?php echo "<b>What3Words:</b> ".$venue->w3w; ?></div>
        </div>
    </div>



    <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="  w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  font-semibold text-white bg-violet-600">Online entries</div>
        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $price = $purchase->stripe_price / 100;
                $name = $purchase->product_name;
                $quantity = $purchase->purchases;
                $total = $price * $quantity;

            ?>
            <div class="flex justify-between text-sm w-full pl-4 pr-4">
                <div class="table-cell min-w-10 text-left"><?php echo e($name); ?></div>
                <div class="table-cell min-w-10 text-left">£<?php echo e($price); ?></div>
                <div class="table-cell w-40 text-end"><?php echo e($quantity); ?></div>
                <div class="table-cell w-40 text-end">£<?php echo e($total); ?></div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="  w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  font-semibold text-white bg-violet-600">Entry list</div>
        <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $entryStatus = $entry->status;
                    $status = $statusArray[$entryStatus];
    //                dd($status);
            ?>
            <div class="flex justify-between text-sm w-full pl-4 pr-4">
                <div class="table-cell w-1/4"><?php echo e($entry->name); ?></div>
                <div class="table-cell w-1/4"><?php echo e($entry->course); ?></div>
                <div class="table-cell w-1/4"><?php echo e($entry->class); ?></div>
                <div class="table-cell w-1/4 text-end"><?php echo e($status); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal485bac47280a588df973e561cc36e261)): ?>
<?php $attributes = $__attributesOriginal485bac47280a588df973e561cc36e261; ?>
<?php unset($__attributesOriginal485bac47280a588df973e561cc36e261); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal485bac47280a588df973e561cc36e261)): ?>
<?php $component = $__componentOriginal485bac47280a588df973e561cc36e261; ?>
<?php unset($__componentOriginal485bac47280a588df973e561cc36e261); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/trials/info.blade.php ENDPATH**/ ?>