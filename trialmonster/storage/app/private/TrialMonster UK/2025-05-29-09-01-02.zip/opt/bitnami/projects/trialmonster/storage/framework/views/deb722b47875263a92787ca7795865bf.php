<?php if (isset($component)) { $__componentOriginal27ace535957143cef069f9d3d7f387f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ace535957143cef069f9d3d7f387f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> <?php echo e($trial->name); ?> <?php $__env->endSlot(); ?>
<?php
//dd($trial)  ;
$owner = (Auth::id());
    $canEdit = false;
if(($owner == $trial->created_by)  && ($trial->isResultPublished)) {
    $canEdit = true;
}

    $courselist = $trial->courselist;
    $classlist = $trial->classlist;
    $numsections = $trial->numSections;
    $numlaps = $trial->numLaps;
                $rawDate = new DateTime($trial->date);
                $date  = date_format($rawDate, "jS F, Y");
                $rawDate = new DateTime($trial->updated_at);
                $updated  = date_format($rawDate, "H:ia jS F, Y");
    $nonStarterArray = array();
foreach($nonStarters as $notStarter) {
    array_push($nonStarterArray, $notStarter->name);
}
    $nonStarterList = implode(', ', $nonStarterArray);

//        dump($trial);
?>

    <div class="tab pl-8">
        <button class="tablinks border border-black border-b-0 rounded-t-lg   hover:bg-blue-500 p-1" id="defaultOpen" onclick="openSection(event, 'Results')">
            Course Results
        </button>
        <button class="tablinks border border-black border-b-0 rounded-t-lg   hover:bg-blue-500 p-1" id="defaultOpen" onclick="openSection(event, 'Class')">
            Class Results
        </button>
        <button class="tablinks border border-black border-b-0 rounded-t-lg    hover:bg-blue-500 p-1  " onclick="openSection(event, 'Scores')">Scores</button>

    </div>
    <div id="Results" class="tabcontent pt-0 ">
        <?php for($course=0;  $course < sizeof($courses); $course++): ?>
            <?php if(sizeof($courseResults[$course]) > 0): ?>

                <div class=" mt-0 mb-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
                    <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600"><?php echo e($courses[$course]); ?></div>
                    <table class="w-full text-sm">
                        <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                            <th class="pl-2 text-right w-10  table-cell">&nbsp;</th>
                            <th class=" w-10 text-right table-cell pr-2">&nbsp;</th>
                            <th class="table-cell">&nbsp;</th>
                            <th class="hidden md:table-cell w-2/12">&nbsp;</th>
                            <th class=" hidden md:table-cell w-2/12">&nbsp;</th>
                            <th class="w-10 text-center table-cell">Total</th>
                            <th class="w-10 text-center table-cell">C</th>
                            <th class="w-10 text-center table-cell">1</th>
                            <th class="w-10 text-center table-cell">2</th>
                            <th class="w-10 text-center table-cell">3</th>
                            <th class="w-10 text-center table-cell">5</th>
                            <th class="pr-4 w-14 text-center table-cell">M</th>
                            <?php if($canEdit): ?>
                                <th class="table-cell">&nbsp;</th>
                            <?php endif; ?>
                        </tr>
                        <?php $__currentLoopData = $courseResults[$course]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php
                                $class = $courseResult->class;
                                if ($class=="Adult" )  {
                                    $class="";
                                }
                                $dnf = $courseResult->resultStatus;
                                $pos = $dnf == 0 ? $courseResult->pos : "DNF";
                                $total = $dnf == 0 ? $courseResult->total : "";
                            ?>
                            <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                                <td class="pl-2 text-right w-10  table-cell font-semibold"><?php echo e($pos); ?></td>
                                <td class=" w-10 text-right table-cell pr-2"><?php echo e($courseResult->rider); ?></td>
                                <td class="table-cell"><?php echo e($courseResult->name); ?></td>
                                <td class="hidden md:table-cell w-2/12"><?php echo e($courseResult->machine); ?></td>
                                <td class=" hidden md:table-cell w-2/12"><?php echo e($class); ?></td>
                                <td class="w-10 font-semibold text-center table-cell"><?php echo e($total); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->cleans); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->ones); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->twos); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->threes); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->fives); ?></td>
                                <td class="pr-4 w-14 text-center table-cell"><?php echo e($courseResult->missed); ?></td>
                                <?php if($canEdit): ?>
                                    <td class=" table-cell"><span><a href="/result/edit/<?php echo e($courseResult->entryID); ?>"><i class=" fa-solid fa-pencil "/></a></span></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            <?php endif; ?>
        <?php endfor; ?>

        
    </div>
    <div id="Class" class="tabcontent pt-0 ">
        <?php for($index=0;  $index < sizeof($resultsByClass); $index++): ?>
          <?php  $course = $resultsByClass[$index][0];
        $class = $resultsByClass[$index][1];
        $classResults = $resultsByClass[$index][2];
        $title = "$course - $class";

//        dump($classResults);
        ?>
            <?php if(sizeof($classResults) > 0): ?>

                <div class=" mt-0 mb-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
                    <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600"><?php echo e($title); ?></div>
                    <table class="w-full text-sm">
                        <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                            <th class="pl-2 text-right w-10  table-cell">&nbsp;</th>
                            <th class=" w-10 text-right table-cell pr-2">&nbsp;</th>
                            <th class="table-cell">&nbsp;</th>
                            <th class="hidden md:table-cell w-2/12">&nbsp;</th>
                            <th class="w-10 text-center table-cell">Total</th>
                            <th class="w-10 text-center table-cell">C</th>
                            <th class="w-10 text-center table-cell">1</th>
                            <th class="w-10 text-center table-cell">2</th>
                            <th class="w-10 text-center table-cell">3</th>
                            <th class="w-10 text-center table-cell">5</th>
                            <th class="pr-4 w-14 text-center table-cell">M</th>
                            <?php if($canEdit): ?>
                                <th class="table-cell">&nbsp;</th>
                            <?php endif; ?>
                        </tr>
                        <?php $__currentLoopData = $classResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php

                                $dnf = $courseResult->resultStatus;
                                $pos = $dnf == 0 ? $courseResult->pos : "DNF";
                                $total = $dnf == 0 ? $courseResult->total : "";
                            ?>
                            <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                                <td class="pl-2 text-right w-10  table-cell font-semibold"><?php echo e($pos); ?></td>
                                <td class=" w-10 text-right table-cell pr-2"><?php echo e($courseResult->rider); ?></td>
                                <td class="table-cell"><?php echo e($courseResult->name); ?></td>
                                <td class="hidden md:table-cell w-2/12"><?php echo e($courseResult->machine); ?></td>
                                <td class="w-10 font-semibold text-center table-cell"><?php echo e($total); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->cleans); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->ones); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->twos); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->threes); ?></td>
                                <td class="w-10 text-center table-cell"><?php echo e($courseResult->fives); ?></td>
                                <td class="pr-4 w-14 text-center table-cell"><?php echo e($courseResult->missed); ?></td>
                                <?php if($canEdit): ?>
                                    <td class=" table-cell"><span><a href="/result/edit/<?php echo e($courseResult->entryID); ?>"><i class=" fa-solid fa-pencil "/></a></span></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            <?php endif; ?>
        <?php endfor; ?>

        
    </div>

    <div id="Scores" class="tabcontent pt-0 ">
        <?php
            if(sizeof($courses) > 0) {
        ?>
        <?php for($course=0;  $course < sizeof($courses); $course++): ?>
            <?php if(sizeof($courseResults[$course]) > 0): ?>
            <div class=" mt-0 mb-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
                <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600"><?php echo e($courses[$course]); ?></div>
                <table class="w-full text-sm">
                    <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                        <th class="pl-2 text-right w-10  table-cell">&nbsp;</th>
                        <th class=" w-10 text-right table-cell pr-2">&nbsp;</th>
                        <th class="table-cell">&nbsp;</th>
                        <th class="w-10 pr-4 font-semibold text-center table-cell">T</th>
                        <?php for($index = 1; $index <= $numsections; $index++): ?>
                        <th class="w-10 pr-4 table-cell text-center"><?php echo e($index); ?></th>
                        <?php endfor; ?>
                    </tr>
                    <?php $__currentLoopData = $courseResults[$course]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php
                            $sectionsScores = $courseResult->sectionScores;
                            $scoreArray = str_split($sectionsScores, $numlaps);
                            $dnf = $courseResult->resultStatus;
                            $pos = $dnf == 0 ? $courseResult->pos : "DNF";
                            $total = $dnf == 0 ? $courseResult->total : "";
                        ?>
                        <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                            <td class="pl-2 text-right w-10  table-cell font-semibold"><?php echo e($pos); ?></td>
                            <td class=" w-10 text-right table-cell pr-2"><?php echo e($courseResult->rider); ?></td>
                            <td class="table-cell"><?php echo e($courseResult->name); ?></td>
                            <td class="w-10 pr-4 font-semibold text-center table-cell"><?php echo e($courseResult->total); ?></td>

                            <?php for($index = 0; $index < $numsections; $index++): ?>
                                <td class="w-10 pr-4 text-center table-cell"><?php echo e($scoreArray[$index]); ?></td>
                            <?php endfor; ?>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php endif; ?>
        <?php endfor; ?>
        <?php
            }
        ?>
    </div>
    <div class="text-black  pt-0 text-sm">
        <div><?php echo e($trial->club); ?></div>
        <div><?php echo e($trial->venue); ?></div>
        <div>Permit: <?php echo e($trial->permit); ?></div>
        <div>Last updated: <?php echo e($updated); ?></div>
    </div>
    <script>
        // Get the element with id="defaultOpen" and click on it
        document.getElementById("defaultOpen").click();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $attributes = $__attributesOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__attributesOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $component = $__componentOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__componentOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/results/detail.blade.php ENDPATH**/ ?>