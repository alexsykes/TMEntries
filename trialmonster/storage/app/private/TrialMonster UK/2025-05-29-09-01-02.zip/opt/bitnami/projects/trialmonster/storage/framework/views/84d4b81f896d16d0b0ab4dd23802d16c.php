<div class="sm:col-span-4">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/components/form-field.blade.php ENDPATH**/ ?>