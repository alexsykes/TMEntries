<?php if (isset($component)) { $__componentOriginal485bac47280a588df973e561cc36e261 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal485bac47280a588df973e561cc36e261 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.club','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('club'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> Scoring grid <?php $__env->endSlot(); ?>
    <?php
        $isScoringLocked = $trial->isScoringLocked;
        $isTrialLocked = $trial->isLocked;
        if($isScoringLocked || $isTrialLocked) {
            $lock = true;
        } else {
            $lock = false;
        }

        $numRows    = $trial->numRows;
        $numColumns = $trial->numColumns;
        $numSections = $trial->numSections;
        $numLaps = $trial->numLaps;

        $numRiders = $numRows * $numColumns;
    ?>
    <style>
        table {
            table-layout: fixed;
        }
    </style>
    <form method="post" action="/scores/confirmPublish">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="trialID" name="trialID" value="<?php echo e($trial->id); ?>">
        <a href="/adminTrials"
           class="rounded-md bg-white px-3 py-2 text-sm  drop-shadow-lg text-violet-900 shadow-sm hover:bg-violet-900 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-900">Cancel</a>
        <?php if(!$lock): ?>
        <button type="submit"
                class="rounded-md ml-2 bg-red-600 px-3 py-1 text-sm font-light  border border-red-800 text-white drop-shadow-lg hover:bg-red-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">
            Publish
        </button>
            <?php endif; ?>
    </form>
    <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-violet-600">Score grid</div>
        
        
        

        <table class=" w-full ">
            <tr>
                <th>&nbsp;</th>
                <?php
                    for($section = 1; $section<=$numSections; $section++) {
                        $slug = "/scores/sectionScores/$trial->id/$section";
                        echo "<th><a href=\"$slug\">$section</a></th>";
                    }

                ?>
            </tr>
            <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $rider = $score->rider;
                    if(!in_array($rider, $riderNumbers)) {
                ?>
                <tr class="text-red-500 flex-auto odd:bg-white  even:bg-gray-50  border-b ">
                <?php
                    } else {
                ?>
                <tr class="flex-auto odd:bg-white  even:bg-gray-50  border-b">
                    <?php
                        }
                    ?>


                    <td class="pl-4 text-right  pr-2"><?php echo e($rider); ?></td>
                        <?php
                        $sectionScores = str_split($score->scoreData, $numLaps);
                        for ($section = 1; $section <= $numSections; $section++) {
                            $s = $section - 1;
                            $slug = "/scores/sectionScoresForRider/$trial->id/$score->rider/$section";
                            if($lock) {
                                echo "<td class=\"text-center\">$sectionScores[$s]</td>";
                            } else {
                                echo "<td class=\"text-center\"><a href=\"$slug\">$sectionScores[$s]</a></td>";
                            }
                        }
                        ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal485bac47280a588df973e561cc36e261)): ?>
<?php $attributes = $__attributesOriginal485bac47280a588df973e561cc36e261; ?>
<?php unset($__attributesOriginal485bac47280a588df973e561cc36e261); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal485bac47280a588df973e561cc36e261)): ?>
<?php $component = $__componentOriginal485bac47280a588df973e561cc36e261; ?>
<?php unset($__componentOriginal485bac47280a588df973e561cc36e261); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/scoring/grid.blade.php ENDPATH**/ ?>