<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> Trial list <?php $__env->endSlot(); ?>
    <?php
        //        dump($trials);
    ?>
    <div class=" bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="flex justify-between  w-full pt-2 pb-2 pl-4 pr-2 rounded-t-xl  text-white bg-red-600">
            <div class="font-bold">Trial List</div>
            <div class="flex">
                <div class="hidden text-sm sm:block text-center">Trial</div>
                <div class="hidden pl-2 text-sm sm:block text-center">Scoring</div>
                <div class="hidden pl-2 text-sm sm:block text-center">Entries</div>
                <div class="hidden pl-2 text-sm sm:block text-center">Results</div>
                <div class="w-12 text-center text-sm sm:hidden">T</div>
                <div class="w-12 text-center text-sm sm:hidden">S</div>
                <div class="w-12 text-center text-sm sm:hidden">E</div>
                <div class="w-12 text-center text-sm sm:hidden">R</div>
            </div>
        </div>
        <div class="table  w-full text-sm">
            <?php $__currentLoopData = $trials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
//                    dump($trial);
                $rawDate = new DateTime($trial->date);
                $date  = date_format($rawDate, "jS F, Y");
                ?>

                <div class="border-b table-row pr-2 text-red-600">
                    <div class="hidden border-b pt-1 pb-1 pl-2 md:table-cell  "><?php echo e($date); ?></div>
                    <div class="hidden border-b  pr-2 pl-2 md:table-cell "><?php echo e($trial->club); ?></div>
                    <div class="border-b pt-1 pb-1 pr-2 pl-2 table-cell"><?php echo e($trial->name); ?></div>
                    <div class="border-b w-12   table-cell text-center">
                        <a class="table-cell w-full" href="/admin/trial/edit/<?php echo e($trial->id); ?>"><span><i class="fa-solid fa-gear text-black"></i></span></a></div>
                    <div class="border-b w-12   table-cell text-center">
                        <a href="/admin/trial/toggleLock/<?php echo e($trial->id); ?>">
                            <?php if( $trial->isLocked == 0 ): ?><span><i class="fa-solid fa-lock-open text-green-500"></i></span>

                            <?php else: ?>
                                <span><i class="fa-solid fa-lock text-red-600"></i></span>
                            <?php endif; ?>
                        </a>
                    </div>

                    <div class="border-b w-12   table-cell text-center">
                        <a href="/admin/trial/toggleScoring/<?php echo e($trial->id); ?>">
                            <?php if( $trial->isScoringLocked == 0 ): ?>
                                <span><i class="fa-solid fa-lock-open text-green-500"></i></span>

                            <?php else: ?>
                                <span><i class="fa-solid fa-lock text-red-600"></i></span>
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="border-b w-12   table-cell text-center">
                        <a href="/admin/trial/toggleEntry/<?php echo e($trial->id); ?>">
                            <?php if( $trial->isEntryLocked == 0 ): ?><span><i class="fa-solid fa-lock-open text-green-500"></i></span>

                            <?php else: ?>
                                <span><i class="fa-solid fa-lock text-red-600"></i></span>
                            <?php endif; ?>
                        </a>
                    </div>

                    <div class="border-b w-12   table-cell text-center">
                        <a href="/admin/trial/toggleResultPublished/<?php echo e($trial->id); ?>">
                            <?php if( $trial->isResultPublished == 0 ): ?>
                                <span><i class="fa-solid fa-lock-open text-green-500"></i></span>

                            <?php else: ?>
                                <span><i class="fa-solid fa-lock text-red-600"></i></span>
                            <?php endif; ?>
                        </a>
                    </div>


                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/admin/trialList.blade.php ENDPATH**/ ?>