<p><b>We have received a request from your email address to withdraw the entry detailed below. If you did not request this refund, please reply to this email immediately.</b></p>
<p>We can confirm that your refund for the following entry has now been completed.</p>
<table>
    <tr>
        <td>Ref: <?php echo e($entry->id); ?> </td>
        <td><?php echo e($entry->name); ?></td>
        <td><?php echo e($entry->class); ?></td>
        <td><?php echo e($entry->course); ?></td>
    </tr>
</table>

<p>In case of any other enquiries, please reply to this email quoting the Entry Reference.</p>
<p><b>Thank you for entering with TrialMonster</b></p><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/mails/refund_confirmed.blade.php ENDPATH**/ ?>