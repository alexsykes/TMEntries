<?php
$model = $attributes->whereStartsWith('wire:model');
$key = uniqid();
?>

<div <?php echo e($attributes->whereDoesntStartWith('wire:model')); ?> wire:ignore>
    <input name="<?php echo e($name); ?>" id="<?php echo e($id); ?>" value="<?php echo e(old($name, $slot)); ?>" type="hidden">

    <trix-editor
        <?php if($model->first()): ?>
            x-data
            x-on:trix-change="$dispatch('input', event.target.value)"
            x-ref="trix"
            wire:key="<?php echo e($key); ?>"
            <?php echo e($attributes->whereStartsWith('wire:model')); ?>

        <?php endif; ?>
        input="<?php echo e($id); ?>"
        class="<?php echo e($styling); ?>"
    ></trix-editor>
</div>
<?php /**PATH /opt/bitnami/projects/trialmonster/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/editors/trix.blade.php ENDPATH**/ ?>