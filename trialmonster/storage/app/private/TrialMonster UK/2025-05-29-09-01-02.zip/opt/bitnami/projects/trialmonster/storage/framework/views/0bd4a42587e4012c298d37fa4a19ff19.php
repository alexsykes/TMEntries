<div <?php echo e($attributes); ?>>
    <?php echo $toHtml($slot); ?>

</div>
<?php /**PATH /opt/bitnami/projects/trialmonster/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/markdown/markdown.blade.php ENDPATH**/ ?>