<?php if (isset($component)) { $__componentOriginal27ace535957143cef069f9d3d7f387f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ace535957143cef069f9d3d7f387f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main','data' => ['xmlns' => 'http://www.w3.org/1999/html']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['xmlns' => 'http://www.w3.org/1999/html']); ?>
     <?php $__env->slot('heading', null, []); ?> Checkout
     <?php $__env->endSlot(); ?>
    <form method="POST" action="/stripe/checkout">
        <?php echo csrf_field(); ?>
        <?php
            $adultEntryFee = "£".$trial['adultEntryFee'];
            $youthEntryFee = "£".$trial['youthEntryFee'];
            $trial_id = $trial['id'];
//            dd($trial_id);
        ?>

        <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
            <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600">Your entries for <?php echo e($trial->name); ?> </div>
            <table class="w-full ml-4 mr-4"><tr><th>Ref</th><th>Name</th><th>Class</th><th>Course</th><th>Entry fee</th></tr>
                <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><?php echo e($entry->id); ?></td><td><?php echo e($entry->name); ?></td><td><?php echo e($entry->class); ?></td><td><?php echo e($entry->course); ?></td><td><?php echo e(($entry->isYouth == 1) ? $youthEntryFee : $adultEntryFee); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        `       </table>
            <?php
                $entryIDarray = array();
                foreach($entries as $entry){
                    array_push($entryIDarray, $entry->id);
                }
                $entryIDs = implode(',', $entryIDarray);
            ?>
            <input type="hidden" value="<?php echo e($entryIDs); ?>" id="entryIDs" name="entryIDs">
            <input type="hidden" value="<?php echo e($trial_id); ?>" id="trialID" name="trialID">
        </div>
        <div class="mt-4" id="buttons">
            <a href="/entries/register/<?php echo e($trial->id); ?>"  class="rounded-md bg-white px-3 py-2 text-sm  text-blue-600 shadow-sm hover:bg-blue-900 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-900">Back</a>
            <button type="submit" class="rounded-md ml-2 bg-blue-600 px-3 py-1 text-sm font-light  border border-blue-800 text-white drop-shadow-lg hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">Pay</button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $attributes = $__attributesOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__attributesOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $component = $__componentOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__componentOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/entries/checkout.blade.php ENDPATH**/ ?>