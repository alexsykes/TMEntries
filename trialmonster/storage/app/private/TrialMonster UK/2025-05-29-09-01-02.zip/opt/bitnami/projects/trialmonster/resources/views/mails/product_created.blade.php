<p>A new product has been created.</p>

<div>Trial ID: {{ $product->trial_id }}</div>
<div>Name: {{ $product->product_name }}</div>
<div>Price ID: {{ $product->stripe_price_id }}</div>

<p>In case of any other enquiries, please reply to this email quoting the Entry Reference.</p>
<p><b>Thank you for entering with TrialMonster</b></p>