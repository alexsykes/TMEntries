<?php

return [
    'gmap_key' => env('GMAP_KEY'),
];