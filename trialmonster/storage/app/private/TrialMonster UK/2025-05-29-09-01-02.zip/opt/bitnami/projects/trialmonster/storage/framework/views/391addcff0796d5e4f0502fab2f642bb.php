<p>A new product has been created.</p>

<div>Trial ID: <?php echo e($product->trial_id); ?></div>
<div>Name: <?php echo e($product->product_name); ?></div>
<div>Price ID: <?php echo e($product->stripe_price_id); ?></div>

<p>In case of any other enquiries, please reply to this email quoting the Entry Reference.</p>
<p><b>Thank you for entering with TrialMonster</b></p><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/mails/product_created.blade.php ENDPATH**/ ?>