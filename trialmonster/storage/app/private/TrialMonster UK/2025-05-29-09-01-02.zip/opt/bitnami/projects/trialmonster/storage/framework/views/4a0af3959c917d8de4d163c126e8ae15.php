<?php if (isset($component)) { $__componentOriginal27ace535957143cef069f9d3d7f387f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ace535957143cef069f9d3d7f387f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> Club list <?php $__env->endSlot(); ?>

    <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
            <div class="flex justify-between font-bold w-full mt-4 pt-2 pb-2 pl-2 pr-4 rounded-t-xl  text-white bg-blue-600">
                <div><?php echo e($club->name); ?></div>
                <div><?php echo e($club->area); ?></div>
            </div>
            <div class="text-sm pt-2 pl-2 pr-2 pb-2">
                <div class=" "><?php echo $club->description; ?> </div>
                <div class="pt-2 text-blue-800 font-bold">Section markers</div>
                <div class=" "><?php echo $club->section_markers; ?> </div>

                <div class="pt-2 text-blue-800 font-bold">Connections</div>
            <?php if($club->website): ?>
                    <div class=" text-sm">Website: <a href="https://<?php echo e($club->website); ?>" target="_blank"><?php echo e($club->website); ?></a>
                    </div>
                <?php endif; ?>
                <?php if($club->facebook): ?>
                    <div class="  text-sm">Facebook: <a href="https://<?php echo e($club->facebook); ?>" target="_blank"><?php echo e($club->facebook); ?></a>
                    </div>
                <?php endif; ?>

                <?php if($club->series): ?>
                    <div class="pt-2 text-blue-800 font-bold">Competitions</div>
                    <?php $__currentLoopData = $club->series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="font-semibold"><?php echo e($series->name); ?>  - <?php echo e($series->description); ?></div>
                        <div class=""><?php echo $series->notes; ?></div>

                        <div class="flex justify-between pb-2  font-bold w-full  ">
                            <div class="">Courses: <?php echo e($series->courses); ?></div>
                            <div class="">Classes: <?php echo e($series->classes); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $attributes = $__attributesOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__attributesOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $component = $__componentOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__componentOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/clubs/clublist.blade.php ENDPATH**/ ?>