<x-guest-layout><div class="text-center font-semibold text-gray-400">
    TrialMonster is currently undergoing major redevelopment and will reopen shortly.</div>
    <div class="text-center font-semibold text-gray-800 py-10 underline">
    <a href="https://archive.trialmonster.uk">Click here for results from the previous site</a>
</div>
</x-guest-layout>