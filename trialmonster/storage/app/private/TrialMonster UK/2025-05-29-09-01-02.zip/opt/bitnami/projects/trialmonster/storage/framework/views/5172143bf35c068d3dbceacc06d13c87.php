<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => false, 'type'=>'a']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => false, 'type'=>'a']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($type = 'a'): ?>

	<a class="<?php echo e($active ? 'bg-blue-100 border border-white font-light  text-blue-900': 'bg-blue-500 border border-white  text-white hover:bg-blue-200 hover:text-blue-800'); ?> rounded-md px-3 py-1 text-sm font-light"
	   aria-current="<?php echo e($active ? 'page': 'false'); ?>"
			<?php echo e($attributes); ?>


	><?php echo e($slot); ?></a>
<?php else: ?>
	<button class="<?php echo e($active ? '  bg-blue-100 border border-white font-light text-blue-900': 'text-blue-500 border-white  text-white hover:bg-blue-200 hover:text-blue-800'); ?> rounded-md px-3 py-1 text-sm font-light"
			aria-current="<?php echo e($active ? 'page': 'false'); ?>"
			<?php echo e($attributes); ?>


	><?php echo e($slot); ?></button>

<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/components/nav-link.blade.php ENDPATH**/ ?>