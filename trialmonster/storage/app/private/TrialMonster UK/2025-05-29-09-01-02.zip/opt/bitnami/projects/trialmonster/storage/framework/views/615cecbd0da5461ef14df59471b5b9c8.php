<?php if($human): ?>

<time datetime="<?php echo e($date->format($format)); ?>" <?php echo e($attributes); ?>>
    <?php echo e($date->diffForHumans()); ?>

</time>

<?php elseif($local !== null): ?>

<span
    x-data="{
        element: this.$root,
        timestamp: <?php echo e($date->timestamp); ?>

    }"
    x-init="
        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const date = moment.unix(this.timestamp).tz(timeZone);

        this.element.innerHTML = date.format('<?php echo e($local !== true ? $local : 'YYYY-MM-DD HH:mm:ss (z)'); ?>');
    "
    title="<?php echo e($date->diffForHumans()); ?>"
    <?php echo e($attributes); ?>

>
    <?php echo e($date->format('Y-m-d H:i:s')); ?>

</span>

<?php else: ?>

<span title="<?php echo e($date->diffForHumans()); ?>" <?php echo e($attributes); ?>>
    <?php echo e($date->format($format)); ?>

</span>

<?php endif; ?>
<?php /**PATH /opt/bitnami/projects/trialmonster/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/date-time/carbon.blade.php ENDPATH**/ ?>