<p>Your entry has now been updated and the current details are shown below.</p>
<table>
        <tr>
            <td>Ref: <?php echo e($entry->id); ?> </td>
            <td><?php echo e($entry->name); ?></td>
            <td><?php echo e($entry->class); ?></td>
            <td><?php echo e($entry->course); ?></td>
            <td><?php echo e($entry->make); ?> &nbsp;<?php echo e($entry->size); ?></td>
            <td><a href="<?php echo e(config('app.url')); ?>/entry/useredit/?id=<?php echo e($entry->id); ?>&token=<?php echo e($newToken); ?>">Make changes</a></td>
        </tr>
</table>
<p>If you need to make any further changes or withdraw from the event, please click on the link shown following the entry.</p>
<ul>
    <li>Changes may be made to the Course, Class or Bike details.</li>
    <li>No changes may be made to the rider.</li>
    <li>Refunds may be requested until the day preceding the event and will be subject to an administration charge of £3</li>
</ul>
<p>You will receive an email acknowledgement following any further change or request.</p>
<p>In case of any other enquiries, please reply to this email quoting the Entry Reference.</p>
<p><b>Thank you for entering with TrialMonster</b></p><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/mails/entry_changed.blade.php ENDPATH**/ ?>