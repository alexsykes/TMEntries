<?php if (isset($component)) { $__componentOriginal27ace535957143cef069f9d3d7f387f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27ace535957143cef069f9d3d7f387f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
//    dd($toPays);
        $statusOptions = array(    'Payment due', 'Confirmed (Payment received)', 'Withdrawn - paid awaiting refund', 'Refunded', 'Accepted - awaiting payment', 'Reserve', 'Removed', 'Manual entry - to pay', 'Manual entry - paid', 'Manual entry - FoC');
        $entryIDs = array();
$email = Auth::user()->email;
//        dd($entries, $toPays);
    ?>
     <?php $__env->slot('heading', null, []); ?> Entries for <?php echo e($email); ?> <?php $__env->endSlot(); ?>


    <?php if(sizeof($todaysEntries) > 0): ?>
        <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
            <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600">Today's Entries</div>
            <table class="w-full">
                <?php $__currentLoopData = $todaysEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if($entry->status == 0) {
                            array_push($entryIDs, $entry->id);
                            }
                    ?>
                    <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                        <td class="pl-2 table-cell"><?php echo e($entry->name); ?></td>
                        <td class="table-cell"><?php echo e($entry->course); ?></td>
                        <td class="table-cell"><?php echo e($entry->class); ?></td>
                        <td class="table-cell"><?php echo e($statusOptions[$entry->status]); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td class="pl-2 table-cell text-center text-blue-800 font-semibold" colspan="4">Requests for changes should be made with the organiser at Sign-on</td>
            </table>
        </div>
    <?php endif; ?>
    <?php if(sizeof($toPays) > 0): ?>
    <div class=" mt-0 mb-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-red-600">Unconfirmed Entries - your entry is not confirmed until payment is completed</div>
        <table class="w-full">
            <?php $__currentLoopData = $toPays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    if($entry->status == 0) {
                        array_push($entryIDs, $entry->id);
                        }
                ?>
                <tr class="pr-4 odd:bg-white  even:bg-gray-50 border-b ">
                    <td class="pl-2    table-cell"><?php echo e($entry->trial); ?></td>
                    <td class="table-cell"><?php echo e($entry->name); ?></td>
                    <td class="table-cell"><?php echo e($entry->course); ?></td>
                    <td class="table-cell"><?php echo e($entry->class); ?></td>
                    <?php if($entry->isEntryLocked == 1): ?>
                        <td class="table-cell">Locked</td>
                    <?php else: ?>
                        <td class="table-cell"><?php echo e($statusOptions[$entry->status]); ?></td>
                    <?php endif; ?>
                    <td class="table-cell"><a href="/users/entry/edit/<?php echo e($entry->id); ?>">Edit</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <form action="/stripe/checkout" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class=" rounded-md  bg-blue-600 px-3 py-1 text-sm font-light  border border-blue-800 text-white drop-shadow-lg hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">Checkout</button>
        <input type="hidden" id="entryIDs" name="entryIDs" value="<?php echo e(implode(',',$entryIDs)); ?>" >
    </form>
<?php endif; ?>

    <?php if(sizeof($entries) > 0): ?>
    <div class=" mt-4 bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-blue-600">Current Entries</div>
        <table class="w-full">
            <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                if($entry->status == 0) {
                    array_push($entryIDs, $entry->id);
                    }
                ?>
                <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
                    <td class="pl-2    table-cell"><?php echo e($entry->trial); ?></td>
                    <td class="table-cell"><?php echo e($entry->name); ?></td>
                    <td class="table-cell"><?php echo e($entry->course); ?></td>
                    <td class="table-cell"><?php echo e($entry->class); ?></td>
                    <td class="table-cell"><?php echo e($statusOptions[$entry->status]); ?></td>
                    <?php if($entry->isEntryLocked == 1): ?>
                        <td class="table-cell"><i class="fa-solid fa-lock"></i></td>
                    <?php else: ?>
                        <td class="table-cell"><a href="/users/entry/edit/<?php echo e($entry->id); ?>"><i class="fa-solid fa-pencil"></i></a></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="text-center pt-2 text-blue-800 font-semibold">Click on the pencil to makes changes or cancel an entry</div>
    </div>
        <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $attributes = $__attributesOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__attributesOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27ace535957143cef069f9d3d7f387f4)): ?>
<?php $component = $__componentOriginal27ace535957143cef069f9d3d7f387f4; ?>
<?php unset($__componentOriginal27ace535957143cef069f9d3d7f387f4); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/user/entry_list.blade.php ENDPATH**/ ?>