<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> User List <?php $__env->endSlot(); ?>
    <?php
//        dd($users);
    ?>
    <div class="  bg-white border-1 border-gray-400 rounded-xl  outline outline-1 -outline-offset-1 drop-shadow-lg outline-gray-300 pb-2">
        <div class="font-bold w-full pt-2 pb-2 pl-4 pr-4 rounded-t-xl  text-white bg-red-600">&nbsp;</div>
    <table class="w-full text-sm">
        <tr>
            <th class="table-cell pl-4  pt-1  pb-1   hidden  md:table-cell">ID</th>
            <th class="table-cell pl-4">Name</th>
            <th class="table-cell pl-4">Email</th>
            <th class="table-cell pl-4">Club User</th>
            <th class="table-cell pl-4">Admin User</th>
            <th class="table-cell pl-4">Super User</th>
            <th class="table-cell pl-4">&nbsp;</th>
            <th class="table-cell pl-4">&nbsp;</th>

        </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $isAdminUser = $user->isAdminUser == 1 ? "Y" : "";
            $isClubUser = $user->isClubUser == 1 ? "Y" : "";
            $isSuperUser = $user->isSuperUser == 1 ? "Y" : "";

        ?>
            <tr class="pr-4 odd:bg-white  even:bg-gray-50  border-b ">
        <td class="text-right table-cell pl-4  pt-1  pb-1   hidden  md:table-cell"><?php echo e($user->id); ?></td>
        <td class="table-cell pl-4"><?php echo e($user->name); ?></td>
        <td class="table-cell pl-4"><?php echo e($user->email); ?></td>
        <td class="text-center table-cell  pl-4"><?php echo e($isClubUser); ?></td>
        <td class="text-center table-cell pl-4"><?php echo e($isAdminUser); ?></td>
        <td class="text-center table-cell pl-4"><?php echo e($isSuperUser); ?></td>
                <td class="font-semibold table-cell pl-4"><a class="underline" href="/admin/editUser/<?php echo e($user->id); ?>"><i class="text-blue-800 fa-solid fa-gear"></i></a></td>
                <td class="font-semibold table-cell pl-4 pr-4"><a class="underline" href="/admin/user/remove/<?php echo e($user->id); ?>">
                        <?php if(!$isSuperUser): ?>
                            <i class="text-red-500 fa-solid fa-trash"></i>
                        <?php endif; ?>

                    </a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>

    <div>
        <?php echo e($users->links()); ?>


    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/admin/userList.blade.php ENDPATH**/ ?>