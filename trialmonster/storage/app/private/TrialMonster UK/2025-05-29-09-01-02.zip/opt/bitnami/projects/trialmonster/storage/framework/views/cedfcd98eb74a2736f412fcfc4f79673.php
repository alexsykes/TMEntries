<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => false, 'type'=>'a']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => false, 'type'=>'a']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<footer class="flex flex-wrap flex-col items-center px-4 pt-6 pb-2 text-sm ">
   <div class="pt-2 <?php echo e($active ? ' text-violet-400': ' text-violet-800 hover:bg-violet-2 hover:text-violet-300'); ?> rounded-md  text-sm font-light"
       aria-current="<?php echo e($active ? 'page': 'false'); ?>"
            <?php echo e($attributes); ?> ><?php echo e($slot); ?>

   </div>
</footer><?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/components/footer-link.blade.php ENDPATH**/ ?>