<textarea id="notes">Hello, World!</textarea>
