<?php
$model = $attributes->whereStartsWith('wire:model')->first();
$isLive = filled($attributes->whereStartsWith('wire:model.live')->first()) ? 'true' : 'false';
?>

<div wire:ignore>
    <textarea
        x-data="{
            easyMDE: null
        }"
        x-init="
            this.easyMDE = new EasyMDE({ element: $root <?php echo e($jsonOptions()); ?> });

            <?php if($model): ?>
                this.easyMDE.codemirror.on('change', () => {
                    $wire.$set('<?php echo e($model); ?>', this.easyMDE.value(), <?php echo e($isLive); ?>)
                });
            <?php endif; ?>
        "
        name="<?php echo e($name); ?>"
        id="<?php echo e($id); ?>"
        <?php echo e($attributes); ?>

    ><?php echo e(old($name, $slot)); ?></textarea>
</div>
<?php /**PATH /opt/bitnami/projects/trialmonster/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/editors/easy-mde.blade.php ENDPATH**/ ?>