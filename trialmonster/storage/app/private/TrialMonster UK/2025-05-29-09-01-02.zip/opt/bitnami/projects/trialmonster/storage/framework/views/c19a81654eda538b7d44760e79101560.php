<textarea id="notes">Hello, World!</textarea>
<?php /**PATH /opt/bitnami/projects/trialmonster/resources/views/components/forms/tinymce-editor.blade.php ENDPATH**/ ?>