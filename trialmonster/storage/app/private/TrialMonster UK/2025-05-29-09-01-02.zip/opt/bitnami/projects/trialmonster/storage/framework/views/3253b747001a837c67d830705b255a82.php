<input
    x-data
    x-init="new Pikaday({ field: $root <?php echo e($jsonOptions()); ?> })"
    name="<?php echo e($name); ?>"
    type="text"
    id="<?php echo e($id); ?>"
    placeholder="<?php echo e($placeholder); ?>"
    <?php if($value): ?>value="<?php echo e($value); ?>"<?php endif; ?>
    <?php echo e($attributes); ?>

/>
<?php /**PATH /opt/bitnami/projects/trialmonster/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/forms/inputs/pikaday.blade.php ENDPATH**/ ?>