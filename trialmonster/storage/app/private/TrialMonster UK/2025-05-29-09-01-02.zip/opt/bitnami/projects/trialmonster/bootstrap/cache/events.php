<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'Illuminate\\Auth\\Events\\Login' => 
    array (
      0 => 'App\\Listeners\\OnLogin@handle',
    ),
    'Laravel\\Cashier\\Events\\WebhookReceived' => 
    array (
      0 => 'App\\Listeners\\StripeEventListener@handle',
    ),
  ),
);